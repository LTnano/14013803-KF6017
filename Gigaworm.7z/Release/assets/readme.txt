Sources
Chris Rook provided assets - Asteroid, cannons, launch, explosion
Elite Dangerous - Rumble explosion
Battlefleet Gothic Armada 2 - Impacts and Bangs
Myself - Worm, Worm armour, fighters, missiles, ships and stations
https://www.videvo.net/ - Shoot
https://mattwalkden.itch.io/free-robot-warfare-pack - Explosion effects

